import capi_demo1 as cd1
# To use this run in the terminal: python setup.py build_ext --inplace
# And on Nova: python3.8.5 setup.py build_ext --inplace
print(cd1.geo(0.5, 100))