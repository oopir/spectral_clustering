#ifndef CAP_H_
#define CAP_H_

double geo_c(double z, int n);

#endif
